This is the MS COCO API downloaded from https://github.com/pdollar/coco. I have slightly modified it for convenience reasons.
