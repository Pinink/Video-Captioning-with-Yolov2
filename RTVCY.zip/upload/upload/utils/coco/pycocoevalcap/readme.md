This is the MS COCO caption evaluation API downloaded from https://github.com/tylin/coco-caption. 
